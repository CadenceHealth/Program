//below code adapted from https://github.com/pablorr18/TiFlexiGrid

var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.resourcesDirectory, 'dataTemp');
var items=[];

var clickAction = function(e){
	var view = Alloy.createController('viewSaved',{
		image: e.source.data.image
	}).getView();
	view.open();
};

if (dir.exists()) {
	Ti.API.info('Directory list to start: ' + dir.getDirectoryListing());
	// it's empty

}
var listing = dir.getDirectoryListing();
var files = [];
for (var i = 0; i < listing.length; i++) {
	var file = Titanium.Filesystem.getFile(Titanium.Filesystem.resourcesDirectory, dir.name, listing[i]);
	var blob = file.read();
	files[i] = {title: 'lol',image: blob};
}

Ti.API.info(blob.nativePath);


$.fg.init({
    columns:3,
    space:5,
    gridBackgroundColor:'#fff',
    itemHeightDelta: 0,
    itemBackgroundColor:'#eee',
    itemBorderColor:'transparent',
    itemBorderWidth:0,
    itemBorderRadius:0,
    onItemClick: clickAction
});

for(var i = 0; i<files.length; i++){
	var view = Alloy.createController('grid',{
			image:files[i].image,
			width:$.fg.getItemWidth(),
			height:$.fg.getItemHeight()
		}).getView();
	var values = {
        title: files[i].title,
        image: files[i].image
    };
    items.push({
        view: view,
        data: values
    });
};

$.fg.addGridItems(items);

/*
for(var i =0; i < files.length; i++){
	var img = Ti.UI.createImageView({image:files[i]});
	img.addEventListener('click', function(e){
		console.log('HELLO WORLD');
	});
	img.top = 0;
	img.width = '32%';
	switch(i%3){
			case 0:
				img.left = '1%';
				break;
			case 1:
				img.left = '34%';
				break;
			
			case 2:
				img.left = '67%';
				break;
	
		}
	
	
	$.grid.add(img);
}
*/

// dispose of file handle & blob.
//file = null;
//blob = null;

/*
var gridWin = photogrid.createWindow({
data: data
});
*/

//$.grid.add(gridWin);
//gridWin.open();

function navigateHome(e) {
	$.localMeals.close();
}

function sortByA() {}
function sortByB() {}
function sortByC() {}


/*
The MIT License (MIT)

Copyright (c) 2014 Pablo Rodriguez Ruiz, @pablorr18

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
