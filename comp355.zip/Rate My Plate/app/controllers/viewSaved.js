var args = arguments[0] || {};
$.img.image = args.image;