win = Ti.UI.currentWindow;


//Sub windows
var tagMeal;
var searchMeals = Alloy.createController('searchMeals').getView();
var localMeals = Alloy.createController('localMeals').getView();

function navigateHome() {
	
}

function openSearchMeals(e) {

	searchMeals.open();
	$.navigation.close;
}

function openLocalMeals(e) {
	
	localMeals.open();
	$.navigation.close;
}

function CaptureMeal(e) {
    Titanium.Media.showCamera({
	success:function(event) {
		// called when media returned from the camera
		Ti.API.debug('Our type was: '+event.mediaType);
		if(event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
			var imageView = Ti.UI.createImageView({
				width:Ti.UI.SIZE,
				height:Ti.UI.SIZE,
				image:event.media
			});
			
			//save image to temp 
			newImage = imageView.toBlob();
	
			//pass image location to Tag
			var arg = {
				image : newImage	
				};
			
			//create controller and pass image location
			openTagMeal(arg);
		} else {
			alert("got the wrong type back ="+event.mediaType);
		}
	},
	cancel:function() {
		// called when user cancels taking a picture
		alert("Meal Creation cancelled");
	},
	error:function(error) {
		// called when there's an error
		var a = Titanium.UI.createAlertDialog({title:'Camera'});
		if (error.code == Titanium.Media.NO_CAMERA) {
			a.setMessage('Please run this test on device');
		} else {
			a.setMessage('Unexpected error: ' + error.code);
		}
		a.show();
	},
	saveToPhotoGallery:false,
});
}

function openTagMeal(data) {
	tagMeal = Alloy.createController('tagMeal', data).getView();
	tagMeal.open();
	$.navigation.close;
}

