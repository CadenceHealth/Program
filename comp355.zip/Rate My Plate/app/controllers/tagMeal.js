//Store image for display
var args = arguments[0] || {};
console.log(args);
var image = args.image;
$.image.image = image;

function openEditMeal(){
	if ($.tagField.value != "") {
		var editMeal= Alloy.createController('editMeal').getView();
		console.log($.tagField.value);
		var arg = {
			tag : $.tagField.value
		};
		editMeal.open(arg);
		$.tagMeal.close();
	}
}

function navigateHome(e) {
	index.open();
	$.tagMeal.close();
}
