function navigateHome(e) {
	$.search.close();
	//var index = Alloy.createController('index').getView();
	index.open();
}

function search(){
	alert('you entered ' + $.textField.value);
}
