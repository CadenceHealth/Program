var args = arguments[0] || {};
console.log(args);


var tags = args.tag;
var location;
var id;
var ingr = [];
var oracRating;

var ingredients = [];

generateTable();

// read in our routes from a comma-separated file 
function generateTable() {
	var f = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory,'ingredientsList.csv'); 
	var csv = f.read(); 
	var lines = csv.toString().split("\n"); 
	for (var i=1; i<lines.length; i++) { 
		var line = lines[i]; 
		var ingredient = line.split(","); 
		if (ingredient.length == 3) { 
			var name = ingredient[0]; 
			var serving = ingredient[1]; 
			var orac = ingredient[2]; 
			entry = {name: name, size: serving, oracRating: orac, quantity: 0};
			ingredients.push(entry); 
		} 
	}
	
	
	var tableData = [];
	
	for (var i=0; i<ingredients.length; i++) {
	  	var row = Ti.UI.createTableViewRow({
	  		title: ingredients[i].name
	  	});
	 	
	  	var labelIngredient = Ti.UI.createLabel({
	    	color:'#576996',
	    	text: ingredients[i].name,
	    	left:20, width:200, height: 20
	  	});
	  	row.add(labelIngredient);
	  
	  	var labelServe = Ti.UI.createLabel({
	    	color:'#222',
	    	text: ingredients[i].size,
	    	left:200, width:50, height: 20
	  	});
	  	row.add(labelServe);
	 
	  	var subButton = Ti.UI.createButton({
	  		title:'<',   
	    	left:250, height:25, width:30,
	  	});
	  	row.add(subButton);
	  
	  	var addButton = Ti.UI.createButton({
	  		title:'>',   
	    	left:310, height:25, width:30,
	  	});
	  	row.add(addButton);
	  
	 	var labelQuantity = Ti.UI.createLabel({
	  		color:'#576996',
	    	text: ingredients[i].quantity,
	    	left:285, width:20, height: 20
	  	});
	  	row.add(labelQuantity);
	 
	  	var filter = ingredients[i].name;
	  	row.filter = filter;
	 	
	 	tableData.push(row);
	  
		subButton.row = i;
	  	subButton.addEventListener('click', function(e) {
			Ti.API.log('Button clicked on row ' + e.source.row);
		    var index = e.source.row;
		    var quantity = ingredients[index].quantity;
		    if (quantity > 0) {
		    	quantity--;
		    }
		    ingredients[index].quantity = quantity;
		    var rows = $.table.data[0].rows;
		    var row = rows[index];
		    row.children[4].text = quantity + "";
		    $.table.updateRow(index, row);
		    
		    Ti.API.log('quantity now is ' + ingredients[index].quantity);
		});
		
		addButton.row = i;
		addButton.addEventListener('click', function(e) {
			Ti.API.log('Button clicked on row ' + e.source.row);
		    var index = e.source.row;
		    var quantity = ingredients[index].quantity;
		    quantity++;
		    ingredients[index].quantity = quantity;
		    var rows = $.table.data[0].rows;
		    var row = rows[index];
		    row.children[4].text = quantity + "";
		    $.table.updateRow(index, row);
		    Ti.API.log('quantity now is ' + ingredients[index].quantity);
		});
		
		
	}
	
	var tabSearch = Alloy.createController("searchView").getView();
	tabSearch.backgroundColor = '#7e8aa2';
	$.table.search = tabSearch;	
	$.table.filterAttribute = 'title';
	$.table.data = tableData;
}

function generateOrac() {
	var count = 0;
	for (var i = 0; i < ingredients.length; i++) {
		if (ingredients[i] > 0) {
			ingr[count] = ingredients[i].name + "|" + ingredients[i].quantity;
			oracRating += ingredients[i].orac * ingredients[i].quantity;
			count++;
		}
	}
	
	addToDatabase();	
}

function addToDatabase() {
	
	var rowTxt = "";
	id = getDate();
	location = "DOES NOT EXIST";
	
	rowTxt = id 	 + "," +
			tags 	 + "," +
			location + "," + 
			ingr	 + "," + 
			oracRating + "\n";
			
	var localDatabase = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'localData.csv');
	localDatabase.write(rowTxt);
	
	if(localDatabase.exists) {
		alert("CSV generated");
	}
	console.log(localDatabase.read);
}

function getDate() {
	var currentTime = new Date();
    var hours = currentTime.getHours();
    var minutes = currentTime.getMinutes();
    var seconds = currentTime.getSeconds();
    var month = currentTime.getMonth() + 1;
    var day = currentTime.getDate();
    var year = currentTime.getFullYear();
 
    if (hours < 10) { hours = "0" + hours; }
    if (minutes < 10) { minutes = "0" + minutes; }
    if (seconds < 10) { seconds = "0" + seconds; }
 
    return month + "_" + day + "_" + year + "    " + hours + "_" + minutes + "_" + seconds;
}

function navigateHome() {
	alert("Meal Creation cancelled");
	index.open();
	$.editMeal.close();
}