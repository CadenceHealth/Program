var args = arguments[0] || {};
console.log(args);
var image = args.image;
$.image.image = image;

function click(){
	var search= Alloy.createController('editMeal').getView();
	search.open();
}

function navigateHome(e) {
	$.tagMeal.close();
}
