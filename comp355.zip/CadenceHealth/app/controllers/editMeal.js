var tags;
var location;
var id;
var oracRating;

// read in our routes from a comma-separated file 
var f = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory,'ingredientsList.csv'); 
var csv = f.read(); 
var ingredients = [];
var lines = csv.toString().split("\n"); 
for (var i=1; i<lines.length; i++) { 
	var line = lines[i]; 
	var ingredient = line.split(","); 
	if (ingredient.length == 3) { 
		var name = ingredient[0]; 
		var serving = ingredient[1]; 
		var orac = ingredient[2]; 
		entry = {name: name, size: serving, oracRating: orac, quantity: 0};
		ingredients.push(entry); 
	} 
}


var tableData = [];

for (var i=0; i<ingredients.length; i++) {
  var row = Ti.UI.createTableViewRow({
    className:'ingredientRow', // used to improve table performance
    selectedBackgroundColor:'white',
    rowIndex:i, // custom property, useful for determining the row during events
    height:40
  });
  /*
  var imageAvatar = Ti.UI.createImageView({
    image: IMG_BASE + 'custom_tableview/user.png',
    left:10, top:5,
    width:50, height:50
  });
  row.add(imageAvatar);
  */
 
  var labelIngredient = Ti.UI.createLabel({
    color:'#576996',
    text: ingredients[i].name,
    left:20, top: 6,
    width:200, height: 30
  });
  row.add(labelIngredient);
  
  var labelServe = Ti.UI.createLabel({
    color:'#222',
    text: ingredients[i].size,
    left:220, top:6,
    width:50
  });
  row.add(labelServe);
  
  var subButton = Ti.UI.createButton({
  	backgroundColour: '#666',
  	text: '-',
  	left: 290,
  	top: 6,
  	width: 20
  });
  row.add(subButton);
  
  var addButton = Ti.UI.createButton({
  	backgroundColour: '#666',
  	text: '+',
  	left: 350,
  	top: 6,
  	width: 20
  });
  row.add(addButton);
  
  var labelQuantity = Ti.UI.createLabel({
  	color:'#576996',
    text: ingredients[i].quantity,
    left:320, top: 6,
    width:20, height: 30
  });
  row.add(labelQuantity);
 
  var filter = ingredients[i].name;
  row.filter = filter;
 	
  tableData.push(row);
}

var searchBar = Ti.UI.createSearchBar();
var tabSearch = Alloy.createController("searchView").getView();

var ingredientsTable = Ti.UI.createTableView({
	width	: Ti.UI.Fill,
	height	: 200,
	top		: 0,
	search	: tabSearch,
	data	: tableData,
	filterAttribute : 'filter'
});


/*var tabSearch = Alloy.createController("searchView").getView();
$.table.search = tabSearch;	
$.editMeal.addEventListener("open", function() {
    $.editMeal.activity.onCreateOptionsMenu = function(e) {
        e.menu.add({
            title: "Add Ingredients",
            actionView: tabSearch,
            showAsAction : Ti.Android.SHOW_AS_ACTION_ALWAYS | Ti.Android.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW
        });
    };
    $.editMeal.activity.invalidateOptionsMenu();
});
*/

$.table = ingredientsTable;
//$.editMeal.open();

function navigateHome(e) {
	$.editMeal.close();
}