function navigateHome(e) {
	$.search.close();
}
