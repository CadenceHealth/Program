function navigateHome() {}

function openHelpPage() {}

function openSettingsPage() {}

function openAboutPage() {}

var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "myMeals");

dir.exists() || dir.createDirectory();

Ti.API.info("Directory list to start: " + dir.getDirectoryListing());

var index = Alloy.createController("index").getView();

var win = Ti.UI.currentWindow;

index.open();

Alloy.createController("index");