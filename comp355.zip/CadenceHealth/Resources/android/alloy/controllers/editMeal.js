function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId0() {
        $.__views.editMeal.removeEventListener("open", __alloyId0);
        if ($.__views.editMeal.activity) {
            $.__views.editMeal.activity.actionBar.title = "Healthy Appetite";
            $.__views.editMeal.activity.actionBar.displayHomeAsUp = true;
            $.__views.editMeal.activity.actionBar.icon = "/actionicon.png";
            $.__views.editMeal.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId5() {
        $.__views.editMeal.removeEventListener("open", __alloyId5);
        if ($.__views.editMeal.activity) $.__views.editMeal.activity.onCreateOptionsMenu = function(e) {
            var __alloyId2 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId2, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId2, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId3 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId3, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId3, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId4 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId4, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId4, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function navigateHome() {
        $.editMeal.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "editMeal";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.editMeal = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "editMeal"
    });
    $.__views.editMeal && $.addTopLevelView($.__views.editMeal);
    $.__views.editMeal.addEventListener("open", __alloyId0);
    $.__views.editMeal.addEventListener("open", __alloyId5);
    $.__views.__alloyId6 = Ti.UI.createView({
        backgroundColor: "white",
        id: "__alloyId6"
    });
    $.__views.editMeal.add($.__views.__alloyId6);
    $.__views.table = Ti.UI.createTableView({
        id: "table"
    });
    $.__views.__alloyId6.add($.__views.table);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var f = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, "ingredientsList.csv");
    var csv = f.read();
    var ingredients = [];
    var lines = csv.toString().split("\n");
    for (var i = 1; i < lines.length; i++) {
        var line = lines[i];
        var ingredient = line.split(",");
        if (3 == ingredient.length) {
            var name = ingredient[0];
            var serving = ingredient[1];
            var orac = ingredient[2];
            entry = {
                name: name,
                size: serving,
                oracRating: orac,
                quantity: 0
            };
            ingredients.push(entry);
        }
    }
    var tableData = [];
    for (var i = 0; i < ingredients.length; i++) {
        var row = Ti.UI.createTableViewRow({
            className: "ingredientRow",
            selectedBackgroundColor: "white",
            rowIndex: i,
            height: 40
        });
        var labelIngredient = Ti.UI.createLabel({
            color: "#576996",
            text: ingredients[i].name,
            left: 20,
            top: 6,
            width: 200,
            height: 30
        });
        row.add(labelIngredient);
        var labelServe = Ti.UI.createLabel({
            color: "#222",
            text: ingredients[i].size,
            left: 220,
            top: 6,
            width: 50
        });
        row.add(labelServe);
        var subButton = Ti.UI.createButton({
            backgroundColour: "#666",
            text: "-",
            left: 290,
            top: 6,
            width: 20
        });
        row.add(subButton);
        var addButton = Ti.UI.createButton({
            backgroundColour: "#666",
            text: "+",
            left: 350,
            top: 6,
            width: 20
        });
        row.add(addButton);
        var labelQuantity = Ti.UI.createLabel({
            color: "#576996",
            text: ingredients[i].quantity,
            left: 320,
            top: 6,
            width: 20,
            height: 30
        });
        row.add(labelQuantity);
        var filter = ingredients[i].name;
        row.filter = filter;
        tableData.push(row);
    }
    Ti.UI.createSearchBar();
    var tabSearch = Alloy.createController("searchView").getView();
    var ingredientsTable = Ti.UI.createTableView({
        width: Ti.UI.Fill,
        height: 200,
        top: 0,
        search: tabSearch,
        data: tableData,
        filterAttribute: "filter"
    });
    $.table = ingredientsTable;
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;