function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId7() {
        $.__views.navigation.removeEventListener("open", __alloyId7);
        if ($.__views.navigation.activity) {
            $.__views.navigation.activity.actionBar.title = "Healthy Appetite";
            $.__views.navigation.activity.actionBar.displayHomeAsUp = true;
            $.__views.navigation.activity.actionBar.icon = "/actionicon.png";
            $.__views.navigation.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId12() {
        $.__views.navigation.removeEventListener("open", __alloyId12);
        if ($.__views.navigation.activity) $.__views.navigation.activity.onCreateOptionsMenu = function(e) {
            var __alloyId9 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId9, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId9, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId10 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId10, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId10, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId11 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId11, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId11, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function openSearchMeals() {
        searchMeals = Alloy.createController("searchMeals").getView();
        searchMeals.open();
    }
    function openLocalMeals() {
        localMeals = Alloy.createController("localMeals").getView();
        localMeals.open();
    }
    function CaptureMeal() {
        Titanium.Media.showCamera({
            success: function(event) {
                Ti.API.debug("Our type was: " + event.mediaType);
                if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                    var imageView = Ti.UI.createImageView({
                        width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        image: event.media
                    });
                    newImage = imageView.toBlob();
                    var arg = {
                        image: newImage
                    };
                    openTagMeal(arg);
                } else alert("got the wrong type back =" + event.mediaType);
            },
            cancel: function() {
                alert("Meal Creation cancelled");
            },
            error: function(error) {
                var a = Titanium.UI.createAlertDialog({
                    title: "Camera"
                });
                a.setMessage(error.code == Titanium.Media.NO_CAMERA ? "Please run this test on device" : "Unexpected error: " + error.code);
                a.show();
            },
            saveToPhotoGallery: false
        });
    }
    function openTagMeal(data) {
        tagMeal = Alloy.createController("tagMeal", data).getView();
        tagMeal.open();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.navigation = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "navigation"
    });
    $.__views.navigation && $.addTopLevelView($.__views.navigation);
    $.__views.navigation.addEventListener("open", __alloyId7);
    $.__views.navigation.addEventListener("open", __alloyId12);
    $.__views.home = Ti.UI.createView({
        backgroundColor: "white",
        top: 50,
        id: "home"
    });
    $.__views.navigation.add($.__views.home);
    $.__views.CaptureButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "96%",
        height: "47%",
        left: "2%",
        top: "2%",
        id: "CaptureButton",
        title: "Snap & Tag"
    });
    $.__views.home.add($.__views.CaptureButton);
    CaptureMeal ? $.__views.CaptureButton.addEventListener("click", CaptureMeal) : __defers["$.__views.CaptureButton!click!CaptureMeal"] = true;
    $.__views.SearchButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "47%",
        height: "47%",
        left: "2%",
        top: "51%",
        id: "SearchButton",
        title: "Search Meals"
    });
    $.__views.home.add($.__views.SearchButton);
    openSearchMeals ? $.__views.SearchButton.addEventListener("click", openSearchMeals) : __defers["$.__views.SearchButton!click!openSearchMeals"] = true;
    $.__views.SavedButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "47%",
        height: "47%",
        left: "51%",
        top: "51%",
        id: "SavedButton",
        title: "Saved Meals"
    });
    $.__views.home.add($.__views.SavedButton);
    openLocalMeals ? $.__views.SavedButton.addEventListener("click", openLocalMeals) : __defers["$.__views.SavedButton!click!openLocalMeals"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    win = Ti.UI.currentWindow;
    var tagMeal;
    Alloy.createController("editMeal").getView();
    var searchMeals;
    var localMeals;
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    __defers["$.__views.CaptureButton!click!CaptureMeal"] && $.__views.CaptureButton.addEventListener("click", CaptureMeal);
    __defers["$.__views.SearchButton!click!openSearchMeals"] && $.__views.SearchButton.addEventListener("click", openSearchMeals);
    __defers["$.__views.SavedButton!click!openLocalMeals"] && $.__views.SavedButton.addEventListener("click", openLocalMeals);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;