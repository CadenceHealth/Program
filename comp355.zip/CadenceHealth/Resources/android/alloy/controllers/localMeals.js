function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId13() {
        $.__views.localMeals.removeEventListener("open", __alloyId13);
        if ($.__views.localMeals.activity) {
            $.__views.localMeals.activity.actionBar.title = "Healthy Appetite";
            $.__views.localMeals.activity.actionBar.displayHomeAsUp = true;
            $.__views.localMeals.activity.actionBar.icon = "/actionicon.png";
            $.__views.localMeals.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId18() {
        $.__views.localMeals.removeEventListener("open", __alloyId18);
        if ($.__views.localMeals.activity) $.__views.localMeals.activity.onCreateOptionsMenu = function(e) {
            var __alloyId15 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId15, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId15, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId16 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId16, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId16, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId17 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId17, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId17, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function navigateHome() {
        $.localMeals.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "localMeals";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.localMeals = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "localMeals"
    });
    $.__views.localMeals && $.addTopLevelView($.__views.localMeals);
    $.__views.fg = Alloy.createWidget("com.prodz.tiflexigrid", "widget", {
        id: "fg",
        __parentSymbol: $.__views.localMeals
    });
    $.__views.fg.setParent($.__views.localMeals);
    $.__views.localMeals.addEventListener("open", __alloyId13);
    $.__views.localMeals.addEventListener("open", __alloyId18);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.resourcesDirectory, "dataTemp");
    var items = [];
    var clickAction = function(e) {
        var view = Alloy.createController("viewSaved", {
            image: e.source.data.image
        }).getView();
        view.open();
    };
    dir.exists() && Ti.API.info("Directory list to start: " + dir.getDirectoryListing());
    var listing = dir.getDirectoryListing();
    var files = [];
    for (var i = 0; i < listing.length; i++) {
        var file = Titanium.Filesystem.getFile(Titanium.Filesystem.resourcesDirectory, dir.name, listing[i]);
        var blob = file.read();
        files[i] = {
            title: "lol",
            image: blob
        };
    }
    Ti.API.info(blob.nativePath);
    $.fg.init({
        columns: 3,
        space: 5,
        gridBackgroundColor: "#fff",
        itemHeightDelta: 0,
        itemBackgroundColor: "#eee",
        itemBorderColor: "transparent",
        itemBorderWidth: 0,
        itemBorderRadius: 0,
        onItemClick: clickAction
    });
    for (var i = 0; i < files.length; i++) {
        var view = Alloy.createController("grid", {
            image: files[i].image,
            width: $.fg.getItemWidth(),
            height: $.fg.getItemHeight()
        }).getView();
        var values = {
            title: files[i].title,
            image: files[i].image
        };
        items.push({
            view: view,
            data: values
        });
    }
    $.fg.addGridItems(items);
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;