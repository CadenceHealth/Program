var args = arguments[0] || {};

function changeSync(){
	//insert syncing stuff here
}

function navigateHome() {
	index.open();
	$.win.close();
}