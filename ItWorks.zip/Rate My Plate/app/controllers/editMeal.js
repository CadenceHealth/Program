var args = arguments[0] || {};
console.log("These are the args" + args);

var f = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'temp.png');

var tags = args.tag;
var location = args.location;
var id = "";
var ingr = "";
var oracRating = 0;

var ingredients = [];

generateTable();

// read in our routes from a comma-separated file 
function generateTable() {
	var f = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory,'ingredientList.csv'); 
	var csv = f.read(); 
	var lines = csv.toString().split("\n"); 
	for (var i=1; i<lines.length; i++) { 
		var line = lines[i]; 
		var ingredient = line.split(",*,"); 
		if (ingredient.length == 2) { 
			var name = ingredient[0].replace(/\"/g, "");
			var other = ingredient[1].split(",");
			if (other.length == 3) { 
				var serving = other[1] + " " + other[0];
				var orac = parseInt(other[2]); 
				entry = {name: name, size: serving, oracRating: orac, quantity: 0};
				ingredients.push(entry); 
			} 
		}
	}
	
	
	var tableData = [];
	
	for (var i=0; i<ingredients.length; i++) {
	  	var row = Ti.UI.createTableViewRow({
	  		title: ingredients[i].name
	  	});
	 	
	  	var labelIngredient = Ti.UI.createLabel({
	    	color:'#576996',
	    	text: ingredients[i].name,
	    	left: '1%', 
	    	width: '60%', 
	    	height: 'auto',
	    	wordWrap: true
	  	});
	  	row.add(labelIngredient);
	  
	  	var labelServe = Ti.UI.createLabel({
	    	color:	'#222',
	    	text: 	ingredients[i].size,
	    	left: 	'62%', 
	    	width:	'15%',
	    	height: 'auto',
	    	wordWrap: true
		});
	  	row.add(labelServe);
	 
	  	var subButton = Ti.UI.createButton({
	  		backgroundImage: '/icons/subButton.jpg',   
	  		backgroundSelectedImage: '/icons/subButtonSelected.jpg',  
	    	right:48, height:20, width:20
	  	});
	  	row.add(subButton);
	  
	  	var addButton = Ti.UI.createButton({
	  		backgroundImage: '/icons/addButton.jpg',
	  		backgroundSelectedImage: '/icons/addButtonSelected.jpg',  
	    	right:4, height:20, width:20
	  	});
	  	row.add(addButton);
	  
	 	var labelQuantity = Ti.UI.createLabel({
	  		color:'#576996',
	    	text: ingredients[i].quantity,
	    	right:26, width:20, height: 20
	  	});
	  	row.add(labelQuantity);
	 
	  	var filter = ingredients[i].name;
	  	row.filter = filter;
	 	
	 	tableData.push(row);
	  
		subButton.row = i;
	  	subButton.addEventListener('click', function(e) {
		    var index = e.source.row;
		    var quantity = ingredients[index].quantity;
		    if (quantity > 0) {
		    	quantity--;
		    }
		    ingredients[index].quantity = quantity;
		    var rows = $.table.data[0].rows;
		    var row = rows[index];
		    row.children[4].text = quantity + "";
		    $.table.updateRow(index, row);		   
		});
		
		addButton.row = i;
		addButton.addEventListener('click', function(e) {
		    var index = e.source.row;
		    var quantity = ingredients[index].quantity;
		    quantity++;
		    ingredients[index].quantity = quantity;
		    var rows = $.table.data[0].rows;
		    var row = rows[index];
		    row.children[4].text = quantity + "";
		    $.table.updateRow(index, row);		
		});
		
		
	}
	
	var tabSearch = Alloy.createController("searchView").getView();
	tabSearch.backgroundColor = '#ff9800';
	$.table.search = tabSearch;	
	$.table.filterAttribute = 'title';
	$.table.data = tableData;
}

function generateOrac() {
	var count = 0;
	for (var i = 0; i < ingredients.length; i++) {
		if (ingredients[i].quantity > 0) {
			var ingrOrac = parseInt(ingredients[i].oracRating) * ingredients[i].quantity;
			oracRating += ingrOrac;
			ingr += ingredients[i].name + "-" + ingredients[i].quantity + "-" + ingrOrac + "|";
			count++;
		}
	}
	
	addToDatabase();	
}

function addToDatabase() {
	
	var rowTxt = "";
	id = getDate();
	location = "DOES NOT EXIST";
	rowTxt = id 	 + "," +
			tags 	 + "," +
			location + "," + 
			oracRating +
			"*^" +
			ingr + "\n";

	var path = id+'.png';
	var filename = Ti.Filesystem.applicationDataDirectory + '/myMeals/' + path;
	var mealFile = Ti.Filesystem.getFile(filename);
	var image = args.image;
	var test = mealFile.write(image);
	image = null;
	f = null;
	
	if (test === false) {
		console.log("Write Error");
	}
	console.log("Write complete? " + test);
	
	var meals = localDatabase.read();
	var lines = meals.toString()+rowTxt; 
	localDatabase.write(lines);
	
	console.log(lines);
	
	openMeal();
}

function getDate() {
	var currentTime = new Date();
    var hours = currentTime.getHours();
    var minutes = currentTime.getMinutes();
    var seconds = currentTime.getSeconds();
    var month = currentTime.getMonth() + 1;
    var day = currentTime.getDate();
    var year = currentTime.getFullYear();
 
    if (hours < 10) { hours = "0" + hours; }
    if (minutes < 10) { minutes = "0" + minutes; }
    if (seconds < 10) { seconds = "0" + seconds; }
 
    return month + "_" + day + "_" + year + " " + hours + "_" + minutes + "_" + seconds;
}

function navigateHome() {
	alert("Meal Creation cancelled");
	index.open();
	$.editMeal.close();
}

function openMeal() {

	
	var view = Alloy.createController('viewSaved',{
		image: args.image,
		link: id
	}).getView();
	view.open();
	$.editMeal.close();
}
