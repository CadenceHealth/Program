//Store image for display
var args = arguments[0] || {};
$.image.image = args.image;
console.log(args.image);

function openEditMeal(){
	if ($.tagField.value != "") {
		var arg = {
			image : args.image,
			location : "NOT IMPLEMENTED",
			tag : $.tagField.value
		};
		var editMeal= Alloy.createController('editMeal', arg).getView();
		
		editMeal.open();
		$.tagMeal.close();
	}
}

function navigateHome(e) {
	index.open();
	$.tagMeal.close();
}
