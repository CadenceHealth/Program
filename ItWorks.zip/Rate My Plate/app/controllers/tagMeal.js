//Store image for display
var args = arguments[0] || {};
console.log(args.image);
var image = args.image;
$.image.image = image;

function openEditMeal(){
	if ($.tagField.value != "") {
		var arg = {
			img : args.image,
			location : "NOT IMPLEMENTED",
			tag : $.tagField.value
		};
		var editMeal= Alloy.createController('editMeal', arg).getView();
		
		editMeal.open();
		$.tagMeal.close();
	}
}

function navigateHome(e) {
	index.open();
	$.tagMeal.close();
}
