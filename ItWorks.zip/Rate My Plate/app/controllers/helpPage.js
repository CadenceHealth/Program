var args = arguments[0] || {};

function navigateHome() {
	index.open();
	$.win.close();
}