win = Ti.UI.currentWindow;
var ImageFactory = require('ti.imagefactory');

//Sub windows
var tagMeal;
var searchMeals;
var localMeals;

function navigateHome() {
	
}

function openSearchMeals(e) {
    searchMeals = Alloy.createController('searchMeals').getView();
	searchMeals.open();
	$.navigation.close;
}

function openLocalMeals(e) {
	localMeals = Alloy.createController('localMeals').getView();
	localMeals.open();
	$.navigation.close;
}

function CaptureMeal(e) {
    Titanium.Media.showCamera({
	success:function(event) {
		// called when media returned from the camera
		var image = event.media;
		
		console.log('Our type was: '+event.mediaType);
		if(event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
			var imageView = Ti.UI.createImageView({
				width:Ti.UI.SIZE,
				height:Ti.UI.SIZE,
			});
	console.log("ABOUt TO RUN TO BLOB");		
			//save image to temp 
			//newImage = ImageFactory.compress(imageView.toBlob(), 0.0);
			var filename = Ti.Filesystem.applicationDataDirectory + '/' + 'temp' + '.png';
			var f = Ti.Filesystem.getFile(filename);
			
			var newBlob = ImageFactory.imageAsResized(image, {
				 width: 1024, 
				 height: 1380, 
				 quality: 0.8
				});
			image = null;
			f.write(newBlob);
			imageView.image = f.nativePath;
			
	console.log("RAN TO BLOB");
			//pass image location to Tag
			var arg = {
				image: newBlob
			};
			//create controller and pass image location
			openTagMeal(arg);
			newBlob = null;
		} else {
			alert("got the wrong type back ="+event.mediaType);
		}
	},
	cancel:function() {
		// called when user cancels taking a picture
		alert("Meal Creation cancelled");
	},
	error:function(error) {
		// called when there's an error
		var a = Titanium.UI.createAlertDialog({title:'Camera'});
		if (error.code == Titanium.Media.NO_CAMERA) {
			a.setMessage('Please run this test on device');
		} else {
			a.setMessage('Unexpected error: ' + error.code);
		}
		a.show();
	},
	saveToPhotoGallery:false,
});
}

function openTagMeal(data) {
	tagMeal = Alloy.createController('tagMeal', data).getView();
	tagMeal.open();
	$.navigation.close;
}

