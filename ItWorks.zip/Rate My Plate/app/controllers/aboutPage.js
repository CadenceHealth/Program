var args = arguments[0] || {};

