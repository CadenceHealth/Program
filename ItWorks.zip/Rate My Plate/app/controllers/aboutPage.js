var args = arguments[0] || {};

$.helpText.html = "<p>" + "Cadence Health is proud to have become one of Australia's favourite spots for nutrition training and CEC approved courses." + "</p>" +
"<p>" + "Rate My Plate is a new application designed to bring awareness of ORAC in your every day lives." + "</p><br>" +		
"<p>" + "ORAC - Oxygen radical absorbance capacity is a method of measuring antioxidant capacities in biological samples through in vitro." + "</p>"+"<br>" +			
"<p>" + "Rate My Plate's aim is to make you Healthier and more aware of what you are eating. This is also the aim of Cadence Health.</p>" + 
"<p>" + "To find out more about Cadence Health, please visit: http://www.cadencehealth.com.au/" + "</p>" + "<br>" +
"<p>" + "This application allows you to:" + "</p>" +
"- Take great pictures of the meals you eat throughout your day, returning you positive feedback on the ORAC value of those meals." + "<br>" +
"- Store and share your meals across the globe via Facebook and the Cadence online database." + "<br>" +
"- Search through the online database to seek healthy meals that others have posted." + "<br>" +
"- View information on the ORAC rating of individual ingredients, with currently over 650 different ingredients included in this application, and kept up to date as more are recorded." +
"<br><br>" +				
"<p>" + "This Application was developed by students of Macquarie University. Developers: Jacob Williams, James Moss. Design: Daniel Richter, Nick Demasi, Rohan Khavare." + "</p>";

function navigateHome() {
	index.open();
	$.win.close();
}