function navigateHome(e) {
	$.search.close();
	index.open();
}

function search(){
	alert('you entered ' + $.textField.value);
}
