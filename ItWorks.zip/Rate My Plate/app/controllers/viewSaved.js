var args = arguments[0] || {};

var csvLink = args.link;
$.img.image = args.image;

generateMealData(csvLink);

//doclick and deleteSaved are new function nothing else has been changed
function doClick(){
	$.dialog.show();
}

function deleteSaved(e){
	if(e.index == 0){
		var csv = localDatabase.read();
		var lines = csv.toString.split('\n');
		$.ViewMeal.close();
	}
}

function generateMealData(link){
	var mealInfo;
	var csv = localDatabase.read(); 
	var lines = csv.toString().split("\n"); 
console.log(link);
	var count = 0;
	while (count < lines.length) { 
		var line = lines[count]; 
		var line = line.split("*^"); 
		var meal = line[0].split(",");
console.log("deats: " +meal);
//console.log("ingr: " +line[1]);
		if (meal[0] == link) {
			mealInfo = {
				date: meal[0], 
				tags: meal[1],
				location: meal[2], 
				oracRating: parseInt(meal[3]),
				ingr: line[1]
				 
			};
		}
		count++;
	}
	
	$.mealTag.text = "Tag: " + mealInfo.tags;
	var dates = mealInfo.date.split(" ");
	$.mealDate.text = "Date Taken: " + dates[0].replace("_","/");
	$.mealLocation.txt = mealInfo.location;
	$.OracRating.text = "ORAC Rating: " + mealInfo.oracRating;
	
	var ingredientArray = mealInfo.ingr.split("|");
console.log("DATA: " +ingredientArray.length);
	var ingredientList = [];
	for (var i = 0; i < ingredientArray.length-1; i++) {
		data = ingredientArray[i].split("-");
console.log("DATA: " +data);
		var per = (parseInt(mealInfo.oracRating) / data[2] * 100).toFixed(0)+'%';

		ingredientList[i] = {
			name: data[0],
			quantity: data[1],
			Orac: data[2]	
		};
		$.ingredients.add(Ti.UI.createLabel({
			text: data[0],
			left: '2%',
			width: '78%'
		}));
		
		$.ingredients.add(Ti.UI.createLabel({
			text: per,
			left: '85%',
			width: '15%'
		}));
	}
}
function navigateHome(e) {
	localMeals = Alloy.createController('localMeals').getView();
	localMeals.open();
	$.ViewMeal.close();
	
}