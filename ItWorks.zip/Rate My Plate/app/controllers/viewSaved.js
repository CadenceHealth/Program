var args = arguments[0] || {};
$.img.image = args.image;
var csvLink = args.link;


generateMealData(csvLink);

function generateMealData(link){
	var mealInfo;
	var csv = localDatabase.read(); 
	var lines = csv.toString().split("\n"); 
console.log(link);
	var count = 0;
	while (count < lines.length) { 
		var line = lines[count]; 
		var line = line.split("*^"); 
		var meal = line[0].split(",");
console.log("deats: " +meal);
//console.log("ingr: " +line[1]);
console.log(meal[0] + " =? " + link + " : " + meal[0] == link);
		if (meal[0] == link) {
			mealInfo = {
				date: meal[0], 
				tags: meal[1],
				location: meal[2], 
				ingr: line[1], 
				oracRating: parseInt(meal[4]) 
			};
		}
		count++;
	}
	
	$.mealTag.text = mealInfo.tags;
	var dates = mealInfo.date.split(" ");
	$.mealDate.text = dates[0];
	$.mealLocation.txt = mealInfo.location;
	$.OracRating.text = mealInfo.oracRating;
	
	
	var ingredientArray = mealInfo.ingr.split("|");
console.log("DATA: " +ingredientArray.length);
	var ingredientList = [];
	for (var i = 0; i < ingredientArray.length; i++) {
		data = ingredientArray[i].split("-");
console.log("DATA: " +data);
		ingredientList[i] = {
			name: data[0],
			quantity: data[1],
			percent: (parseInt(mealInfo.oracRating) / data[2] * 100) + '%'	
		};
		$.ingredients.add(Ti.UI.createLabel({
			text: data[0],
			left: '2%',
			width: '85%'
		}));
		
		$.ingredients.add(Ti.UI.createLabel({
			text: data[2],
			left: '90%',
			width: '8%'
		}));
	}
}
