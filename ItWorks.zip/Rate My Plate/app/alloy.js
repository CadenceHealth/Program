// get a handle to the as-yet non-existent directory
var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory,'myMeals');
var localDatabase = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'localData.csv');
if (!dir.exists()) {
	dir.createDirectory(); // this creates the directory
}

Ti.API.info('Directory list to start: ' + dir.getDirectoryListing()); // it's empty


//Action Bar functions




function openHelpPage(e) {
	var helpPage = Alloy.createController('helpPage').getView();
	helpPage.open();
}

function openSettingsPage(e) {
	var settingsPage = Alloy.createController('settingsPage').getView();
	settingsPage.open();
}

function openAboutPage(e) {
	var aboutPage = Alloy.createController('aboutPage').getView();
	aboutPage.open();
}

function navigateHome() {}

function cleanProject() {
	var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory,'myMeals');
	var db = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'localData.csv');
	if (dir.exists()) {
		//delete the directory
		if(dir.deleteDirectory()==false) {
			Ti.API.info('You cannot delete a directory containing files');
			dir.deleteDirectory(true); // force a recursive directory, which will delete contents
		}
		var cacheDir = Ti.Filesystem.getFile(Ti.Filesystem.applicationCacheDirectory, "/");
		cacheDir.deleteDirectory(true);
	}
	db.write("");
}

//Initialize Index
var index = Alloy.createController('index').getView();
index.open();
