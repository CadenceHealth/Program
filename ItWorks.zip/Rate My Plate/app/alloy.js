// The contents of this file will be executed before any of
// your view controllers are ever executed, including the index.
// You have access to all functionality on the `Alloy` namespace.
//
// This is a great place to do any initialization for your app
// or create any global variables/functions that you'd like to
// make available throughout your app. You can easily make things
// accessible globally by attaching them to the `Alloy.Globals`
// object. For example:
//
// Alloy.Globals.someGlobalFunction = function(){};
//Set up initial Default.



//Create Directory code

/*var f = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory,'myfile.png');
f.write('foo');
var b = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory,'bar.txt');
b.write('foo');
var c = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory,'cat.txt');
c.write('foo');
*/


// get a handle to the as-yet non-existent directory
var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory,'myMeals');

if (!dir.exists()) {
	dir.createDirectory(); // this creates the directory
}


var localDatabase = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'localData.csv');

Ti.API.info('Directory list to start: ' + dir.getDirectoryListing()); // it's empty

// let's move myfile.txt to our directory
//f.move('mysubdir/myfile.txt');
//b.move('mysubdir/bar.txt');
//c.move('mysubdir/cat.txt');

/*
//delete the directory
if(dir.deleteDirectory()==false) {
	Ti.API.info('You cannot delete a directory containing files');
	dir.deleteDirectory(true); // force a recursive directory, which will delete contents
}
// if we try to list the directory, the output is null because the directory doesn't exist
Ti.API.info('Dir list after deleteDirectory(): ' + dir.getDirectoryListing());

// clean the cache directory
var cacheDir = Ti.Filesystem.getFile(Ti.Filesystem.applicationCacheDirectory, "/");
cacheDir.deleteDirectory(true);

localDatabase.write("");
*/


//Action Bar functions
var aboutPage = Alloy.createController('aboutPage').getView();
var helpPage = Alloy.createController('helpPage').getView();
var settingsPage = Alloy.createController('settingsPage').getView();

function openHelpPage(e) {
	helpPage.open();
}

function openSettingsPage(e) {
	settingsPage.open();
}

function openAboutPage(e) {
	
	aboutPage.open();
}

function navigateHome() {}



//Initialize Index
var index = Alloy.createController('index').getView();
index.open();
