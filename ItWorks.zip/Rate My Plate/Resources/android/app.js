function openHelpPage() {
    var helpPage = Alloy.createController("helpPage").getView();
    helpPage.open();
}

function openSettingsPage() {
    var settingsPage = Alloy.createController("settingsPage").getView();
    settingsPage.open();
}

function openAboutPage() {
    var aboutPage = Alloy.createController("aboutPage").getView();
    aboutPage.open();
}

function navigateHome() {}

function cleanProject() {
    var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "myMeals");
    var db = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "localData.csv");
    if (dir.exists()) {
        if (false == dir.deleteDirectory()) {
            Ti.API.info("You cannot delete a directory containing files");
            dir.deleteDirectory(true);
        }
        var cacheDir = Ti.Filesystem.getFile(Ti.Filesystem.applicationCacheDirectory, "/");
        cacheDir.deleteDirectory(true);
    }
    db.write("");
}

var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "myMeals");

var localDatabase = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "localData.csv");

dir.exists() || dir.createDirectory();

Ti.API.info("Directory list to start: " + dir.getDirectoryListing());

var index = Alloy.createController("index").getView();

index.open();

Alloy.createController("index");