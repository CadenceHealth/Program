function openHelpPage() {
    helpPage.open();
}

function openSettingsPage() {
    settingsPage.open();
}

function openAboutPage() {
    aboutPage.open();
}

function navigateHome() {}

var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

var dir = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "myMeals");

dir.exists() || dir.createDirectory();

var localDatabase = Titanium.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "localData.csv");

Ti.API.info("Directory list to start: " + dir.getDirectoryListing());

var aboutPage = Alloy.createController("aboutPage").getView();

var helpPage = Alloy.createController("helpPage").getView();

var settingsPage = Alloy.createController("settingsPage").getView();

var index = Alloy.createController("index").getView();

index.open();

Alloy.createController("index");