function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId29() {
        $.__views.tagMeal.removeEventListener("open", __alloyId29);
        if ($.__views.tagMeal.activity) {
            $.__views.tagMeal.activity.actionBar.title = "Rate My Plate";
            $.__views.tagMeal.activity.actionBar.displayHomeAsUp = true;
            $.__views.tagMeal.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId35() {
        $.__views.tagMeal.removeEventListener("open", __alloyId35);
        if ($.__views.tagMeal.activity) $.__views.tagMeal.activity.onCreateOptionsMenu = function(e) {
            var __alloyId31 = {
                id: "openEditMeal",
                title: "Add Ingredients",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                uiOptions: "splitActionBarWhenNarrow"
            };
            $.__views.openEditMeal = e.menu.add(_.pick(__alloyId31, Alloy.Android.menuItemCreateArgs));
            $.__views.openEditMeal.applyProperties(_.omit(__alloyId31, Alloy.Android.menuItemCreateArgs));
            openEditMeal ? $.__views.openEditMeal.addEventListener("click", openEditMeal) : __defers["$.__views.openEditMeal!click!openEditMeal"] = true;
            var __alloyId32 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId32, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId32, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId33 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId33, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId33, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId34 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId34, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId34, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function openEditMeal() {
        if ("" != $.tagField.value) {
            var arg = {
                img: args.image,
                location: "NOT IMPLEMENTED",
                tag: $.tagField.value
            };
            var editMeal = Alloy.createController("editMeal", arg).getView();
            editMeal.open();
            $.tagMeal.close();
        }
    }
    function navigateHome() {
        index.open();
        $.tagMeal.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "tagMeal";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.tagMeal = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "tagMeal"
    });
    $.__views.tagMeal && $.addTopLevelView($.__views.tagMeal);
    $.__views.tagMeal.addEventListener("open", __alloyId29);
    $.__views.tagMeal.addEventListener("open", __alloyId35);
    $.__views.tagField = Ti.UI.createTextField({
        id: "tagField",
        hintText: "Enter Meal Tag",
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
        color: "#7e8aa2",
        top: "10",
        left: "10",
        width: Ti.UI.SIZE,
        height: "60"
    });
    $.__views.tagMeal.add($.__views.tagField);
    $.__views.image = Ti.UI.createImageView({
        top: "45%",
        left: "2%",
        width: "96%",
        height: "40%",
        id: "image"
    });
    $.__views.tagMeal.add($.__views.image);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    console.log(args.image);
    var image = args.image;
    $.image.image = image;
    __defers["$.__views.openEditMeal!click!openEditMeal"] && $.__views.openEditMeal.addEventListener("click", openEditMeal);
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;