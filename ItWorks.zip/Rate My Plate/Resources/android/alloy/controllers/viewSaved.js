function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function generateMealData(link) {
        var mealInfo;
        var csv = localDatabase.read();
        var lines = csv.toString().split("\n");
        console.log(link);
        var count = 0;
        while (count < lines.length) {
            var line = lines[count];
            var line = line.split("*^");
            var meal = line[0].split(",");
            console.log("deats: " + meal);
            console.log(meal[0] + " =? " + link + " : " + meal[0] == link);
            meal[0] == link && (mealInfo = {
                date: meal[0],
                tags: meal[1],
                location: meal[2],
                ingr: line[1],
                oracRating: parseInt(meal[4])
            });
            count++;
        }
        $.mealTag.text = mealInfo.tags;
        var dates = mealInfo.date.split(" ");
        $.mealDate.text = dates[0];
        $.mealLocation.txt = mealInfo.location;
        $.OracRating.text = mealInfo.oracRating;
        var ingredientArray = mealInfo.ingr.split("|");
        console.log("DATA: " + ingredientArray.length);
        var ingredientList = [];
        for (var i = 0; i < ingredientArray.length; i++) {
            data = ingredientArray[i].split("-");
            console.log("DATA: " + data);
            ingredientList[i] = {
                name: data[0],
                quantity: data[1],
                percent: parseInt(mealInfo.oracRating) / data[2] * 100 + "%"
            };
            $.ingredients.add(Ti.UI.createLabel({
                text: data[0],
                left: "2%",
                width: "85%"
            }));
            $.ingredients.add(Ti.UI.createLabel({
                text: data[2],
                left: "90%",
                width: "8%"
            }));
        }
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "viewSaved";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.__views.ViewMeal = Ti.UI.createWindow({
        backgroundColor: "#ff9800",
        id: "ViewMeal"
    });
    $.__views.ViewMeal && $.addTopLevelView($.__views.ViewMeal);
    $.__views.mealDetails = Ti.UI.createScrollView({
        backgroundColor: "#ff9800",
        top: "2%",
        left: "2%",
        id: "mealDetails"
    });
    $.__views.ViewMeal.add($.__views.mealDetails);
    $.__views.mealTag = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: 4,
        left: "2%",
        id: "mealTag"
    });
    $.__views.mealDetails.add($.__views.mealTag);
    $.__views.mealDate = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: 24,
        left: "2%",
        id: "mealDate"
    });
    $.__views.mealDetails.add($.__views.mealDate);
    $.__views.mealLocation = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: 44,
        left: "2%",
        id: "mealLocation"
    });
    $.__views.mealDetails.add($.__views.mealLocation);
    $.__views.OracRating = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: 64,
        left: "2%",
        id: "OracRating"
    });
    $.__views.mealDetails.add($.__views.OracRating);
    $.__views.img = Ti.UI.createImageView({
        top: 90,
        left: "2%",
        id: "img"
    });
    $.__views.mealDetails.add($.__views.img);
    $.__views.ingredients = Ti.UI.createView({
        top: 290,
        left: "2%",
        id: "ingredients"
    });
    $.__views.mealDetails.add($.__views.ingredients);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    $.img.image = args.image;
    var csvLink = args.link;
    generateMealData(csvLink);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;