function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId39() {
        $.__views.ViewMeal.removeEventListener("open", __alloyId39);
        if ($.__views.ViewMeal.activity) {
            $.__views.ViewMeal.activity.actionBar.title = "Rate My Plate";
            $.__views.ViewMeal.activity.actionBar.displayHomeAsUp = true;
            $.__views.ViewMeal.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId42() {
        $.__views.ViewMeal.removeEventListener("open", __alloyId42);
        if ($.__views.ViewMeal.activity) $.__views.ViewMeal.activity.onCreateOptionsMenu = function(e) {
            var __alloyId41 = {
                id: "del",
                title: "Delete",
                showAsAction: Ti.Android.SHOW_AS_ACTION_NEVER
            };
            $.__views.del = e.menu.add(_.pick(__alloyId41, Alloy.Android.menuItemCreateArgs));
            $.__views.del.applyProperties(_.omit(__alloyId41, Alloy.Android.menuItemCreateArgs));
            doClick ? $.__views.del.addEventListener("click", doClick) : __defers["$.__views.del!click!doClick"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function doClick() {
        $.dialog.show();
    }
    function deleteSaved(e) {
        if (0 == e.index) {
            var csv = localDatabase.read();
            {
                csv.toString.split("\n");
            }
            $.ViewMeal.close();
        }
    }
    function generateMealData(link) {
        var mealInfo;
        var csv = localDatabase.read();
        var lines = csv.toString().split("\n");
        console.log(link);
        var count = 0;
        while (count < lines.length) {
            var line = lines[count];
            var line = line.split("*^");
            var meal = line[0].split(",");
            console.log("deats: " + meal);
            meal[0] == link && (mealInfo = {
                date: meal[0],
                tags: meal[1],
                location: meal[2],
                oracRating: parseInt(meal[3]),
                ingr: line[1]
            });
            count++;
        }
        $.mealTag.text = "Tag: " + mealInfo.tags;
        var dates = mealInfo.date.split(" ");
        $.mealDate.text = "Date Taken: " + dates[0].replace("_", "/");
        $.mealLocation.txt = mealInfo.location;
        $.OracRating.text = "ORAC Rating: " + mealInfo.oracRating;
        var ingredientArray = mealInfo.ingr.split("|");
        console.log("DATA: " + ingredientArray.length);
        var ingredientList = [];
        for (var i = 0; i < ingredientArray.length - 1; i++) {
            data = ingredientArray[i].split("-");
            console.log("DATA: " + data);
            var per = (parseInt(mealInfo.oracRating) / data[2] * 100).toFixed(0) + "%";
            ingredientList[i] = {
                name: data[0],
                quantity: data[1],
                Orac: data[2]
            };
            $.ingredients.add(Ti.UI.createLabel({
                text: data[0],
                left: "2%",
                width: "78%"
            }));
            $.ingredients.add(Ti.UI.createLabel({
                text: per,
                left: "85%",
                width: "15%"
            }));
        }
    }
    function navigateHome() {
        localMeals = Alloy.createController("localMeals").getView();
        localMeals.open();
        $.ViewMeal.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "viewSaved";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.ViewMeal = Ti.UI.createWindow({
        backgroundColor: "#ff9800",
        id: "ViewMeal"
    });
    $.__views.ViewMeal && $.addTopLevelView($.__views.ViewMeal);
    $.__views.ViewMeal.addEventListener("open", __alloyId39);
    $.__views.ViewMeal.addEventListener("open", __alloyId42);
    var __alloyId44 = [];
    __alloyId44.push("Confirm");
    __alloyId44.push("Cancel");
    $.__views.dialog = Ti.UI.createAlertDialog({
        buttonNames: __alloyId44,
        id: "dialog",
        title: "Delete",
        message: "Would you like to delete this file?",
        cancel: "1"
    });
    deleteSaved ? $.__views.dialog.addEventListener("click", deleteSaved) : __defers["$.__views.dialog!click!deleteSaved"] = true;
    $.__views.mealDetails = Ti.UI.createScrollView({
        backgroundColor: "#ff9800",
        top: "2%",
        left: "2%",
        width: "96%",
        id: "mealDetails",
        layout: "vertical"
    });
    $.__views.ViewMeal.add($.__views.mealDetails);
    $.__views.details = Ti.UI.createView({
        left: "5%",
        width: "90%",
        height: "80",
        id: "details",
        layout: "vertical",
        backgroundColor: "white"
    });
    $.__views.mealDetails.add($.__views.details);
    $.__views.mealTag = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        id: "mealTag"
    });
    $.__views.details.add($.__views.mealTag);
    $.__views.mealDate = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        id: "mealDate"
    });
    $.__views.details.add($.__views.mealDate);
    $.__views.mealLocation = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        id: "mealLocation"
    });
    $.__views.details.add($.__views.mealLocation);
    $.__views.OracRating = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        id: "OracRating"
    });
    $.__views.details.add($.__views.OracRating);
    $.__views.img = Ti.UI.createImageView({
        left: "2%",
        width: "96%",
        height: "auto",
        id: "img"
    });
    $.__views.mealDetails.add($.__views.img);
    $.__views.ingredients = Ti.UI.createView({
        left: "2%",
        width: "96%",
        height: "auto",
        id: "ingredients",
        layout: "vertical",
        backgroundColor: "white"
    });
    $.__views.mealDetails.add($.__views.ingredients);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    var csvLink = args.link;
    $.img.image = args.image;
    generateMealData(csvLink);
    __defers["$.__views.del!click!doClick"] && $.__views.del.addEventListener("click", doClick);
    __defers["$.__views.dialog!click!deleteSaved"] && $.__views.dialog.addEventListener("click", deleteSaved);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;