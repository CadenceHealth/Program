function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId49() {
        $.__views.win.removeEventListener("open", __alloyId49);
        if ($.__views.win.activity) {
            $.__views.win.activity.actionBar.title = "Rate My Plate";
            $.__views.win.activity.actionBar.displayHomeAsUp = true;
            $.__views.win.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function navigateHome() {
        index.open();
        $.win.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "aboutPage";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.__views.win = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "win"
    });
    $.__views.win && $.addTopLevelView($.__views.win);
    $.__views.win.addEventListener("open", __alloyId49);
    $.__views.__alloyId50 = Ti.UI.createScrollView({
        id: "__alloyId50"
    });
    $.__views.win.add($.__views.__alloyId50);
    $.__views.__alloyId51 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId51"
    });
    $.__views.__alloyId50.add($.__views.__alloyId51);
    $.__views.head = Ti.UI.createImageView({
        top: "0%",
        width: "100%",
        id: "head",
        image: "/cadence.jpg"
    });
    $.__views.__alloyId51.add($.__views.head);
    $.__views.helpText = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        id: "helpText"
    });
    $.__views.__alloyId51.add($.__views.helpText);
    exports.destroy = function() {};
    _.extend($, $.__views);
    arguments[0] || {};
    $.helpText.html = "<p>Cadence Health is proud to have become one of Australia's favourite spots for nutrition training and CEC approved courses.</p><p>Rate My Plate is a new application designed to bring awareness of ORAC in your every day lives.</p><br><p>ORAC - Oxygen radical absorbance capacity is a method of measuring antioxidant capacities in biological samples through in vitro.</p><br><p>Rate My Plate's aim is to make you Healthier and more aware of what you are eating. This is also the aim of Cadence Health.</p><p>To find out more about Cadence Health, please visit: http://www.cadencehealth.com.au/</p><br><p>This application allows you to:</p>- Take great pictures of the meals you eat throughout your day, returning you positive feedback on the ORAC value of those meals.<br>- Store and share your meals across the globe via Facebook and the Cadence online database.<br>- Search through the online database to seek healthy meals that others have posted.<br>- View information on the ORAC rating of individual ingredients, with currently over 650 different ingredients included in this application, and kept up to date as more are recorded.<br><br><p>This Application was developed by students of Macquarie University. Developers: Jacob Williams, James Moss. Design: Daniel Richter, Nick Demasi, Rohan Khavare.</p>";
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;