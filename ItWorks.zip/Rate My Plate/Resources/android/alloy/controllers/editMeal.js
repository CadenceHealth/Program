function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId0() {
        $.__views.editMeal.removeEventListener("open", __alloyId0);
        if ($.__views.editMeal.activity) {
            $.__views.editMeal.activity.actionBar.title = "Rate My Plate";
            $.__views.editMeal.activity.actionBar.displayHomeAsUp = true;
            $.__views.editMeal.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId7() {
        $.__views.editMeal.removeEventListener("open", __alloyId7);
        if ($.__views.editMeal.activity) $.__views.editMeal.activity.onCreateOptionsMenu = function(e) {
            var __alloyId3 = {
                title: "Generate ORAC Rating",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                uiOptions: "splitActionBarWhenNarrow",
                id: "__alloyId2"
            };
            $.__views.__alloyId2 = e.menu.add(_.pick(__alloyId3, Alloy.Android.menuItemCreateArgs));
            $.__views.__alloyId2.applyProperties(_.omit(__alloyId3, Alloy.Android.menuItemCreateArgs));
            generateOrac ? $.__views.__alloyId2.addEventListener("click", generateOrac) : __defers["$.__views.__alloyId2!click!generateOrac"] = true;
            var __alloyId4 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId4, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId4, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId5 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId5, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId5, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId6 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId6, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId6, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function generateTable() {
        var f = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, "ingredientList.csv");
        var csv = f.read();
        var lines = csv.toString().split("\n");
        for (var i = 1; i < lines.length; i++) {
            var line = lines[i];
            var ingredient = line.split(",*,");
            if (2 == ingredient.length) {
                var name = ingredient[0].replace(/\"/g, "");
                var other = ingredient[1].split(",");
                if (3 == other.length) {
                    var serving = other[1] + " " + other[0];
                    var orac = parseInt(other[2]);
                    entry = {
                        name: name,
                        size: serving,
                        oracRating: orac,
                        quantity: 0
                    };
                    ingredients.push(entry);
                }
            }
        }
        var tableData = [];
        for (var i = 0; i < ingredients.length; i++) {
            var row = Ti.UI.createTableViewRow({
                title: ingredients[i].name
            });
            var labelIngredient = Ti.UI.createLabel({
                color: "#576996",
                text: ingredients[i].name,
                left: "1%",
                width: "60%",
                height: "auto",
                wordWrap: true
            });
            row.add(labelIngredient);
            var labelServe = Ti.UI.createLabel({
                color: "#222",
                text: ingredients[i].size,
                left: "62%",
                width: "15%",
                height: "auto",
                wordWrap: true
            });
            row.add(labelServe);
            var subButton = Ti.UI.createButton({
                backgroundImage: "/icons/subButton.jpg",
                backgroundSelectedImage: "/icons/subButtonSelected.jpg",
                right: 48,
                height: 20,
                width: 20
            });
            row.add(subButton);
            var addButton = Ti.UI.createButton({
                backgroundImage: "/icons/addButton.jpg",
                backgroundSelectedImage: "/icons/addButtonSelected.jpg",
                right: 4,
                height: 20,
                width: 20
            });
            row.add(addButton);
            var labelQuantity = Ti.UI.createLabel({
                color: "#576996",
                text: ingredients[i].quantity,
                right: 26,
                width: 20,
                height: 20
            });
            row.add(labelQuantity);
            var filter = ingredients[i].name;
            row.filter = filter;
            tableData.push(row);
            subButton.row = i;
            subButton.addEventListener("click", function(e) {
                var index = e.source.row;
                var quantity = ingredients[index].quantity;
                quantity > 0 && quantity--;
                ingredients[index].quantity = quantity;
                var rows = $.table.data[0].rows;
                var row = rows[index];
                row.children[4].text = quantity + "";
                $.table.updateRow(index, row);
            });
            addButton.row = i;
            addButton.addEventListener("click", function(e) {
                var index = e.source.row;
                var quantity = ingredients[index].quantity;
                quantity++;
                ingredients[index].quantity = quantity;
                var rows = $.table.data[0].rows;
                var row = rows[index];
                row.children[4].text = quantity + "";
                $.table.updateRow(index, row);
            });
        }
        var tabSearch = Alloy.createController("searchView").getView();
        tabSearch.backgroundColor = "#ff9800";
        $.table.search = tabSearch;
        $.table.filterAttribute = "title";
        $.table.data = tableData;
    }
    function generateOrac() {
        var count = 0;
        for (var i = 0; i < ingredients.length; i++) if (ingredients[i].quantity > 0) {
            var ingrOrac = parseInt(ingredients[i].oracRating) * ingredients[i].quantity;
            oracRating += ingrOrac;
            ingr += ingredients[i].name + "-" + ingredients[i].quantity + "-" + ingrOrac + "|";
            count++;
        }
        addToDatabase();
    }
    function addToDatabase() {
        var rowTxt = "";
        id = getDate();
        location = "DOES NOT EXIST";
        rowTxt = id + "," + tags + "," + location + "," + oracRating + "*^" + ingr + "\n";
        var path = id + ".png";
        var filename = Ti.Filesystem.applicationDataDirectory + "/myMeals/" + path;
        var mealFile = Ti.Filesystem.getFile(filename);
        var image = args.image;
        var test = mealFile.write(image);
        image = null;
        f = null;
        false === test && console.log("Write Error");
        console.log("Write complete? " + test);
        var meals = localDatabase.read();
        var lines = meals.toString() + rowTxt;
        localDatabase.write(lines);
        console.log(lines);
        openMeal();
    }
    function getDate() {
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();
        var seconds = currentTime.getSeconds();
        var month = currentTime.getMonth() + 1;
        var day = currentTime.getDate();
        var year = currentTime.getFullYear();
        10 > hours && (hours = "0" + hours);
        10 > minutes && (minutes = "0" + minutes);
        10 > seconds && (seconds = "0" + seconds);
        return month + "_" + day + "_" + year + " " + hours + "_" + minutes + "_" + seconds;
    }
    function navigateHome() {
        alert("Meal Creation cancelled");
        index.open();
        $.editMeal.close();
    }
    function openMeal() {
        var view = Alloy.createController("viewSaved", {
            image: args.image,
            link: id
        }).getView();
        view.open();
        $.editMeal.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "editMeal";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.editMeal = Ti.UI.createWindow({
        backgroundColor: "#ff9800",
        id: "editMeal"
    });
    $.__views.editMeal && $.addTopLevelView($.__views.editMeal);
    $.__views.editMeal.addEventListener("open", __alloyId0);
    $.__views.editMeal.addEventListener("open", __alloyId7);
    $.__views.__alloyId8 = Ti.UI.createView({
        backgroundColor: "#ff9800",
        id: "__alloyId8"
    });
    $.__views.editMeal.add($.__views.__alloyId8);
    $.__views.table = Ti.UI.createTableView({
        backgroundColor: "white",
        id: "table"
    });
    $.__views.__alloyId8.add($.__views.table);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    console.log("These are the args" + args);
    var f = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "temp.png");
    var tags = args.tag;
    var location = args.location;
    var id = "";
    var ingr = "";
    var oracRating = 0;
    var ingredients = [];
    generateTable();
    __defers["$.__views.__alloyId2!click!generateOrac"] && $.__views.__alloyId2.addEventListener("click", generateOrac);
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;