function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function changeSync() {}
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "settingsPage";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.settingsPage = Ti.UI.createWindow({
        id: "settingsPage"
    });
    $.__views.settingsPage && $.addTopLevelView($.__views.settingsPage);
    $.__views.__alloyId36 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: "0%",
        text: "Settings",
        id: "__alloyId36"
    });
    $.__views.settingsPage.add($.__views.__alloyId36);
    $.__views.__alloyId37 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        text: "Sync meals with Cadence servers",
        id: "__alloyId37"
    });
    $.__views.settingsPage.add($.__views.__alloyId37);
    $.__views.sync = Ti.UI.createSwitch({
        value: true,
        id: "sync",
        titleOff: "syncing disabled",
        titleOn: "syncing enabled"
    });
    $.__views.settingsPage.add($.__views.sync);
    changeSync ? $.__views.sync.addEventListener("change", changeSync) : __defers["$.__views.sync!change!changeSync"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    arguments[0] || {};
    __defers["$.__views.sync!change!changeSync"] && $.__views.sync.addEventListener("change", changeSync);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;