function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId47() {
        $.__views.win.removeEventListener("open", __alloyId47);
        if ($.__views.win.activity) {
            $.__views.win.activity.actionBar.title = "Rate My Plate";
            $.__views.win.activity.actionBar.displayHomeAsUp = true;
            $.__views.win.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function changeSync() {}
    function navigateHome() {
        index.open();
        $.win.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "settingsPage";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.win = Ti.UI.createWindow({
        backgroundColor: "#ff9800",
        id: "win"
    });
    $.__views.win && $.addTopLevelView($.__views.win);
    $.__views.win.addEventListener("open", __alloyId47);
    $.__views.__alloyId48 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId48"
    });
    $.__views.win.add($.__views.__alloyId48);
    $.__views.title = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        top: "0%",
        text: "Settings",
        id: "title"
    });
    $.__views.__alloyId48.add($.__views.title);
    $.__views.settings = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        text: "Sync meals with Cadence servers",
        id: "settings"
    });
    $.__views.__alloyId48.add($.__views.settings);
    $.__views.sync = Ti.UI.createSwitch({
        value: true,
        id: "sync",
        titleOff: "Sync Disabled",
        titleOn: "Sync enabled"
    });
    $.__views.__alloyId48.add($.__views.sync);
    changeSync ? $.__views.sync.addEventListener("change", changeSync) : __defers["$.__views.sync!change!changeSync"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    arguments[0] || {};
    __defers["$.__views.sync!change!changeSync"] && $.__views.sync.addEventListener("change", changeSync);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;