function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId15() {
        $.__views.localMeals.removeEventListener("open", __alloyId15);
        if ($.__views.localMeals.activity) {
            $.__views.localMeals.activity.actionBar.title = "Rate My Plate";
            $.__views.localMeals.activity.actionBar.displayHomeAsUp = true;
            $.__views.localMeals.activity.actionBar.onHomeIconItemSelected = navigateHome;
        } else {
            Ti.API.warn("You attempted to access an Activity on a lightweight Window or other");
            Ti.API.warn("UI component which does not have an Android activity. Android Activities");
            Ti.API.warn("are valid with only windows in TabGroups or heavyweight Windows.");
        }
    }
    function __alloyId23() {
        $.__views.localMeals.removeEventListener("open", __alloyId23);
        if ($.__views.localMeals.activity) $.__views.localMeals.activity.onCreateOptionsMenu = function(e) {
            var __alloyId17 = {
                id: "sortA",
                title: "By ORAC Rating",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                uiOptions: "splitActionBarWhenNarrow"
            };
            $.__views.sortA = e.menu.add(_.pick(__alloyId17, Alloy.Android.menuItemCreateArgs));
            $.__views.sortA.applyProperties(_.omit(__alloyId17, Alloy.Android.menuItemCreateArgs));
            sortByA ? $.__views.sortA.addEventListener("click", sortByA) : __defers["$.__views.sortA!click!sortByA"] = true;
            var __alloyId18 = {
                id: "sortB",
                title: "By Date",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                uiOptions: "splitActionBarWhenNarrow"
            };
            $.__views.sortB = e.menu.add(_.pick(__alloyId18, Alloy.Android.menuItemCreateArgs));
            $.__views.sortB.applyProperties(_.omit(__alloyId18, Alloy.Android.menuItemCreateArgs));
            sortByB ? $.__views.sortB.addEventListener("click", sortByB) : __defers["$.__views.sortB!click!sortByB"] = true;
            var __alloyId19 = {
                id: "sortC",
                title: "sortA",
                showAsAction: Ti.Android.SHOW_AS_ACTION_ALWAYS,
                uiOptions: "splitActionBarWhenNarrow"
            };
            $.__views.sortC = e.menu.add(_.pick(__alloyId19, Alloy.Android.menuItemCreateArgs));
            $.__views.sortC.applyProperties(_.omit(__alloyId19, Alloy.Android.menuItemCreateArgs));
            sortByC ? $.__views.sortC.addEventListener("click", sortByC) : __defers["$.__views.sortC!click!sortByC"] = true;
            var __alloyId20 = {
                id: "Help",
                title: "Help"
            };
            $.__views.Help = e.menu.add(_.pick(__alloyId20, Alloy.Android.menuItemCreateArgs));
            $.__views.Help.applyProperties(_.omit(__alloyId20, Alloy.Android.menuItemCreateArgs));
            openHelpPage ? $.__views.Help.addEventListener("click", openHelpPage) : __defers["$.__views.Help!click!openHelpPage"] = true;
            var __alloyId21 = {
                id: "Settings",
                title: "Settings"
            };
            $.__views.Settings = e.menu.add(_.pick(__alloyId21, Alloy.Android.menuItemCreateArgs));
            $.__views.Settings.applyProperties(_.omit(__alloyId21, Alloy.Android.menuItemCreateArgs));
            openSettingsPage ? $.__views.Settings.addEventListener("click", openSettingsPage) : __defers["$.__views.Settings!click!openSettingsPage"] = true;
            var __alloyId22 = {
                id: "About",
                title: "About"
            };
            $.__views.About = e.menu.add(_.pick(__alloyId22, Alloy.Android.menuItemCreateArgs));
            $.__views.About.applyProperties(_.omit(__alloyId22, Alloy.Android.menuItemCreateArgs));
            openAboutPage ? $.__views.About.addEventListener("click", openAboutPage) : __defers["$.__views.About!click!openAboutPage"] = true;
        }; else {
            Ti.API.warn("You attempted to attach an Android Menu to a lightweight Window");
            Ti.API.warn("or other UI component which does not have an Android activity.");
            Ti.API.warn("Android Menus can only be opened on TabGroups and heavyweight Windows.");
        }
    }
    function navigateHome() {
        $.localMeals.close();
    }
    function sortByA() {}
    function sortByB() {}
    function sortByC() {}
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "localMeals";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.localMeals = Ti.UI.createWindow({
        backgroundColor: "#ff9800",
        id: "localMeals"
    });
    $.__views.localMeals && $.addTopLevelView($.__views.localMeals);
    $.__views.fg = Alloy.createWidget("com.prodz.tiflexigrid", "widget", {
        id: "fg",
        __parentSymbol: $.__views.localMeals
    });
    $.__views.fg.setParent($.__views.localMeals);
    $.__views.localMeals.addEventListener("open", __alloyId15);
    $.__views.localMeals.addEventListener("open", __alloyId23);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var dir = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, "myMeals");
    var items = [];
    var clickAction = function(e) {
        var view = Alloy.createController("viewSaved", {
            image: e.source.data.image,
            link: e.source.data.title
        }).getView();
        view.open();
        $.localMeals.close();
    };
    dir.exists() && Ti.API.info("Directory list to start: " + dir.getDirectoryListing());
    var listing = dir.getDirectoryListing();
    var files = [];
    for (var i = 0; i < listing.length; i++) {
        var file = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, dir.name, listing[i]);
        var blob = file.read();
        var path = file.name;
        var name = path.split(".png");
        files[i] = {
            title: name[0],
            image: blob
        };
    }
    $.fg.init({
        columns: 3,
        space: 0,
        gridBackgroundColor: "#fff",
        itemHeightDelta: 0,
        itemBackgroundColor: "#eee",
        itemBorderColor: "transparent",
        itemBorderWidth: 0,
        itemBorderRadius: 0,
        onItemClick: clickAction
    });
    for (var i = 0; i < files.length; i++) {
        var view = Alloy.createController("grid", {
            image: files[i].image,
            width: $.fg.getItemWidth(),
            height: $.fg.getItemHeight()
        }).getView();
        var values = {
            title: files[i].title,
            image: files[i].image
        };
        items.push({
            view: view,
            data: values
        });
    }
    $.fg.addGridItems(items);
    __defers["$.__views.sortA!click!sortByA"] && $.__views.sortA.addEventListener("click", sortByA);
    __defers["$.__views.sortB!click!sortByB"] && $.__views.sortB.addEventListener("click", sortByB);
    __defers["$.__views.sortC!click!sortByC"] && $.__views.sortC.addEventListener("click", sortByC);
    __defers["$.__views.Help!click!openHelpPage"] && $.__views.Help.addEventListener("click", openHelpPage);
    __defers["$.__views.Settings!click!openSettingsPage"] && $.__views.Settings.addEventListener("click", openSettingsPage);
    __defers["$.__views.About!click!openAboutPage"] && $.__views.About.addEventListener("click", openAboutPage);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;