function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "com.prodz.tiflexigrid/" + s : s.substring(0, index) + "/com.prodz.tiflexigrid/" + s.substring(index + 1);
    return true && 0 !== path.indexOf("/") ? "/" + path : path;
}

module.exports = [ {
    isApi: true,
    priority: 1000.0002,
    key: "Label",
    style: {
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000"
    }
}, {
    isClass: true,
    priority: 10000.0001,
    key: "container",
    style: {
        backgroundColor: "#ff9800"
    }
}, {
    isId: true,
    priority: 100000.0002,
    key: "fgMain",
    style: {
        backgroundColor: "#fff",
        height: Ti.UI.FILL,
        width: Ti.UI.FILL
    }
}, {
    isId: true,
    priority: 100000.0003,
    key: "Help",
    style: {}
}, {
    isId: true,
    priority: 100000.0003,
    key: "fgWrapper",
    style: {
        width: Ti.UI.FILL,
        height: Ti.UI.FILL,
        backgroundColor: "transparent"
    }
}, {
    isId: true,
    priority: 100000.0004,
    key: "About",
    style: {}
}, {
    isId: true,
    priority: 100000.0004,
    key: "fgScrollView",
    style: {
        width: Ti.UI.FILL,
        height: Ti.UI.FILL,
        contentHeight: Ti.UI.SIZE,
        contentWidth: Ti.UI.FILL,
        layout: "horizontal",
        backgroundColor: "transparent",
        scrollType: "vertical"
    }
}, {
    isId: true,
    priority: 100000.0005,
    key: "Settings",
    style: {}
}, {
    isId: true,
    priority: 100000.0006,
    key: "actionbar",
    style: {
        displayHomeAsUp: true,
        backgroundColor: "white"
    }
} ];