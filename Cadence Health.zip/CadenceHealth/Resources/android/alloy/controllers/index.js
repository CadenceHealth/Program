function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function navigateSearch() {
        var searchView = Alloy.createController("search").getView();
        searchView.open();
    }
    function navigateSaved() {
        var storageView = Alloy.createController("storage").getView();
        storageView.open();
    }
    function navigateCapture() {
        Titanium.Media.showCamera({
            success: function(event) {
                Ti.API.debug("Our type was: " + event.mediaType);
                if (event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO) {
                    var imageView = Ti.UI.createImageView({
                        width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        image: event.media
                    });
                    newImage = imageView.toBlob();
                    var arg = {
                        image: newImage
                    };
                    var tag = Alloy.createController("tag", arg).getView();
                    tag.open();
                } else alert("got the wrong type back =" + event.mediaType);
            },
            cancel: function() {
                alert("Meal Creation cancelled");
            },
            error: function(error) {
                var a = Titanium.UI.createAlertDialog({
                    title: "Camera"
                });
                a.setMessage(error.code == Titanium.Media.NO_CAMERA ? "Please run this test on device" : "Unexpected error: " + error.code);
                a.show();
            },
            saveToPhotoGallery: false
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.navigation = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "navigation"
    });
    $.__views.navigation && $.addTopLevelView($.__views.navigation);
    $.__views.__alloyId0 = Ti.UI.createView({
        backgroundColor: "white",
        id: "__alloyId0"
    });
    $.__views.navigation.add($.__views.__alloyId0);
    $.__views.CaptureButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "96%",
        height: "47%",
        left: "2%",
        top: "2%",
        id: "CaptureButton",
        title: "Snap & Tag"
    });
    $.__views.__alloyId0.add($.__views.CaptureButton);
    navigateCapture ? $.__views.CaptureButton.addEventListener("click", navigateCapture) : __defers["$.__views.CaptureButton!click!navigateCapture"] = true;
    $.__views.SearchButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "47%",
        height: "47%",
        left: "2%",
        top: "51%",
        id: "SearchButton",
        title: "Search Meals"
    });
    $.__views.__alloyId0.add($.__views.SearchButton);
    navigateSearch ? $.__views.SearchButton.addEventListener("click", navigateSearch) : __defers["$.__views.SearchButton!click!navigateSearch"] = true;
    $.__views.SavedButton = Ti.UI.createButton({
        backgroundColor: "blue",
        width: "47%",
        height: "47%",
        left: "51%",
        top: "51%",
        id: "SavedButton",
        title: "Saved Meals"
    });
    $.__views.__alloyId0.add($.__views.SavedButton);
    navigateSaved ? $.__views.SavedButton.addEventListener("click", navigateSaved) : __defers["$.__views.SavedButton!click!navigateSaved"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.navigation.open();
    __defers["$.__views.CaptureButton!click!navigateCapture"] && $.__views.CaptureButton.addEventListener("click", navigateCapture);
    __defers["$.__views.SearchButton!click!navigateSearch"] && $.__views.SearchButton.addEventListener("click", navigateSearch);
    __defers["$.__views.SavedButton!click!navigateSaved"] && $.__views.SavedButton.addEventListener("click", navigateSaved);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;