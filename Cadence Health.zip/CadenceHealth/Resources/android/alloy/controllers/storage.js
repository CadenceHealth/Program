function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "storage";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.__views.storage = Ti.UI.createWindow({
        id: "storage"
    });
    $.__views.storage && $.addTopLevelView($.__views.storage);
    $.__views.__alloyId2 = Ti.UI.createView({
        backgroundColor: "white",
        id: "__alloyId2"
    });
    $.__views.storage.add($.__views.__alloyId2);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.storage.open();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;