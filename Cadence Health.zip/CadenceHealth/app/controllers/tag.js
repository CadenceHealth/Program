var args = arguments[0] || {};
console.log(args);
var image = args.image;
$.image.image = image;

function viewImage() {
	
}
